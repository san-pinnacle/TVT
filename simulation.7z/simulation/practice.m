clc
clear all;
close all;
%%%%%%%%%%%%%%%%%
 % this progarm generate the BPSk signal and its perfroamnce in compressed
 % doamin using the Hermite  matrix. various compression ratio tests are
 % perfromed  and  compared 
numbits=1;
Ns=1;
Np=10; %Chip period
Nh=7; % cardinality
Ts=10e-9; % frame duration
Tc=1e-9; % chip duration
Fs=25e9;
dt=1./Fs;
%s=repmat([w],1,2); % repeats the sam thing for 2 times 
[bits, stx,ref,framesample]=combined_signal_generation(numbits,Ns,Np,Nh,Ts,Tc,Fs); %% generted tranmitted signal
bitsample=framesample*Ns;
%ebno=inf;


%%recovery process
t=linspace(-1e-9,1e-9,51);
dt=t(2)-t(1);
Fs=1/dt;
tau=.4e-9; %% pulsse width parameter
w=(1-(4*pi.*(t/tau).^2)).*exp(-2*pi.*(t/tau).^2); % second derivative 
w=w/norm(w);

%L=chol(A*A','lower');





ebno=-10:20;
%%% Hermite matrix generation
NN=framesample;
MM=floor((1:10)/10*NN);

 for i=1:10
     M=MM(i);
 for kk=1:1000    
%[A,w]=dictionary_generation(NN, M);
A=randn(M,NN);
L=chol((A*A'),'lower'); 
C=inv(L); 
A=C*A; 
A=normc(A);
A=normr(A);
w1=zeros(1,NN);
w1(1:51)=w(1:end);

% [hf]=cp0802_channel(Fs,1);
% srx=conv(stx,hf);
% srx=srx(1:length(stx));
y=A*w1';
%y=inv(L)*y;
kl=A'*y;
eee(kk)=abs(norm(A*w1')-norm(w1));
clear  A w1
 end
ee(i)=sum(eee)/1000;
 end
 clear eee kl A i w1 w L C  M ebno t dt Fs tau
plot(MM/NN,ee) 

