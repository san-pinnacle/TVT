clc
clear all;
close all;
%%%%%%%%%%%%%%%%%
 % this progarm generate the BPSk signal and its perfroamnce in compressed
 % doamin using the Hermite  matrix. various compression ratio tests are
 % perfromed  and  compared 
numbits=1;
Ns=1;
Np=10; %Chip period
Nh=7; % cardinality
Ts=10e-9; % frame duration
Tc=1e-9; % chip duration
Fs=25e9;
dt=1./Fs;
%s=repmat([w],1,2); % repeats the sam thing for 2 times 
[bits, stx,ref,framesample]=combined_signal_generation(numbits,Ns,Np,Nh,Ts,Tc,Fs); %% generted tranmitted signal
bitsample=framesample*Ns;
%ebno=inf;
ebno=-10:20;
%%% Hermite matrix generation
NN=framesample;
MM=floor(.7*NN);
 %A=randn(MM,NN);
%A = A ./ repmat( sqrt(sum(A.^2)), [MM 1] );  % to normalize the columns
[A,w]=dictionary_generation(NN, MM);
%A=randn(MM,NN);
L=chol((A*A'),'lower'); 
C=inv(L); 
A=C*A; 
A=normc(A);
A=normr(A);



%A=(A*A')\A;
% A1=randn(NN,NN)/sqrt(NN);
% A=A2*A1;
%%%%%%%%%%%% Normalise ths row sand column
%  for i=1:MM
%   A(i,:)=A(i,:)/norm(A(i,:));
%  end
% % Normalise
% for i=1:NN
%     A(:,i)=A(:,i)/norm(A(:,i));
% end
%  A=normc(A);
% A=normr(A);
%A = diag(1./diag( sqrt(A*transpose(A)))) * A;
% %% received signal
[hf]=cp0802_channel(Fs,1);
srx=conv(stx,hf);
srx=srx(1:length(stx));
%%recovery process
t=linspace(-1e-9,1e-9,51);
dt=t(2)-t(1);
Fs=1/dt;
tau=.6e-9; %% pulsse width parameter
w4=((24*pi.*(t/tau).^2)-3-(16*pi^2.*(t/tau).^4)).*exp(-2*pi.*(t/tau).^2); % second derivative 
w4=w4/norm(w4);
srx1=conv(w4,hf);
srx1=srx1(1:length(stx));

w1=zeros(1,NN);
w1(1:51)=w(1:end);
clear w
w=w1;%+.1*randn(1,249);
clear w1
%L=chol(A*A','lower');
y=A*w';
%y=inv(L)*y;
kl=A'*y;

plot(w/norm(w),'r'); hold on;
plot(kl/norm(kl))

H=A'*A;
[U,S,V]=svd(H);


% L=5; S=5; %% number of fingers in rake
% for j=1:5000
% [hf]=cp0802_channel(Fs,1);
% %% received signal
% srx=conv(stx,hf);
% srx=srx(1:length(stx));
% %% nois egeneration
% [output,noise]=cp0801_noise_Ex(stx,ebno,(numbits*Ns));
% [arake, srake,prake]=cp0803_rakechannel(hf,Fs,1e-9,L,S); %% channel estimation
% [ref1]=cp0801_mask(ref,arake); %% reference signal estimation
% %%%%%% noise addtiton
% R=zeros(length(ebno),length(srx));
%  for l=1:length(ebno)
%   R(l,:)=noise(l,:)+srx;
%  end
%  %[ber1(j,:)]=sig_tem_without_cs(R,bits,NN, bitsample,Ns,A,ref1,numbits);
%  [ber1(j,:)]=sig_tem_cs(R,bits,framesample,bitsample,Ns,A,ref1,numbits);
% clear srx hf R noise  ref1
%  end 
% ber=sum(ber1)/5000;
% clear hf ber1 Tf Ns Np L bits R w t framesample framesample1 Fs ho j k  ns stx tau ts
% clear MM NN Ts  prake ml I H dt bitsample arake output ref1 ref S L l Nh numbits Tc
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% semilogy(ebno,ber,'-rd','LineWidth',2); hold on;
% semilogy(ebno,ber_hermite_777,'-*','LineWidth',2); hold on
% semilogy(ebno,ber_hermite_4_moremonte,'--ro','LineWidth',1); hold on;
% 
% 
% 
% % semilogy(ebno,ber_Gaussian_41,'-mo','LineWidth',1); hold on;
% % semilogy(ebno,ber_Gaussian_42,'-m*','LineWidth',1); hold on;
% % semilogy(ebno,ber_hermite_41,'--ro','LineWidth',1); hold on;
% % semilogy(ebno,ber_hermite_42,'--r*','LineWidth',1); hold on;
% 
% legend('$\Phi_{Gaussian}, \ N_{f}=1$','$\Phi_{Gaussian}, \ N_{f}=2$',...
%     '$\Phi_{Proposed}, \ N_{f}=1$', '$\Phi_{Proposed}, \ N_{f}=2$','BestOutside' )
% xlabel('SNR (dB)');
%  ylabel('BER')
% 

ml=randperm(NN);
A1=dctmtx(NN);
A1=A1(ml(1:MM),(1:NN)); 


tmp = repmat({w},MM,1);
M = blkdiag(tmp{:});

