clc;
clear all;
close all;

L=1499;
M=floor(.4*L);
t=linspace(-1e-9,1e-9,51);
dt=t(2)-t(1);
Fs=1/dt;
tau=.4e-9; %% pulsse width parameter
w=(1-(4*pi.*(t/tau).^2)).*exp(-2*pi.*(t/tau).^2); % second derivative 
w=w/norm(w);
%%%%%%%%%% Hermite function   
% ml=randperm(L);
% mk=zeros(1,L);
% [hf]=channel_generation(Fs,1);
% mk1=conv(hf,w);
% mk(1:L)=mk1(1:L);
% %A=toeplitz(mk);
%   for i=1:L
%       delay=.8e-9; 
%       A(i,:)=cp0804_signalshift(mk,Fs,delay);
%       mk=A(i,:);
%   end
% A=A(ml(1:M),(1:L)); 
%A = A ./ repmat( sqrt(sum(A.^2)), [M 1] );  % to normalize the columns
%%% sqrt(sum(A.^2,1)) , for norm calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Hermite function   
ml=randperm(L);
ml1=randperm(L);
% [ho,hf]=channel_generation(Fs,1);
%  w=conv(w,hf);
%  w=w(1:L);
mk=zeros(1,L);
mk(1:51)=w(1:end);
%delay=.60e-9*[1:L];     
%delay=4e-9*randperm(L);   
%delay=1e-9*[1:L];    
  for i=1:L
      delay=.4e-9; 
      A(i,:)=cp0804_signalshift(mk,Fs,delay);
       mk=A(i,:);
 end
A=A(ml(1:M),(1:L)); 
%A = A ./ repmat( sqrt(sum(A.^2)), [M 1] );  % to normalize the columns
%A=A(randsample(1:M,M),1:L); %%% this another method to select random rows;
% Normalise
for i=1:L
    A(:,i)=A(:,i)/norm(A(:,i));
end
% Normalise
for i=1:M
    A(i,:)=A(i,:)/norm(A(i,:));
end





A1=randn(1,L);
A1 = toeplitz(A1);  % to normalize the columns
A1 = A1 ./ repmat( sqrt(sum(A1.^2)), [L 1] );  % to normalize the columns


%A=A./sqrt(trace(A'*A));daspect([400 100 1]); hold on;
% spy(max(A, 0), 'b'); hold on;  %% for sparsity p[lot
% spy(min(A, 0), 'r');
% 
% subplot(2,1,1)
% spy(A,'g');
% 
% subplot(2,1,2)
% spy(max(A1, 0),'b');

%  B=A*A';
%  S = svd(B) ;
%  plot(S)

%  data = sparse(A);
%  imagesc(data)
% axis square
% % colormap('hot')
%  colormap('default')
 spy(A,'b')
xlabel('Signal domain length, N');
 ylabel('Compressed domain length, M')
axis square
 
p = fitdist(M(M>0),'loglogistic') %%% for fit the desribution
u = rand(10000,1);

ksdensity(u, 'Support', [0 1], 'kernel', 'box');
