function [A,w]=dictionary_generation(L, M);
t=linspace(-1e-9,1e-9,51);
dt=t(2)-t(1);
Fs=1/dt;
tau=.4e-9; %% pulsse width parameter
w=(1-(4*pi.*(t/tau).^2)).*exp(-2*pi.*(t/tau).^2); % second derivative 
w=w/norm(w);
%%%%%%%%%% Hermite function   
% ml=randperm(L);
% mk=zeros(1,L);
% [hf]=channel_generation(Fs,1);
% mk1=conv(hf,w);
% mk(1:L)=mk1(1:L);
% %A=toeplitz(mk);
%   for i=1:L
%       delay=.8e-9; 
%       A(i,:)=cp0804_signalshift(mk,Fs,delay);
%       mk=A(i,:);
%   end
% A=A(ml(1:M),(1:L)); 
%A = A ./ repmat( sqrt(sum(A.^2)), [M 1] );  % to normalize the columns
%%% sqrt(sum(A.^2,1)) , for norm calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Hermite function   
ml=randperm(L);
% [ho,hf]=channel_generation(Fs,1);
%  w=conv(w,hf);
%  w=w(1:L);
mk=zeros(1,L);
mk(15:38)=w(15:38);
%delay=.60e-9*[1:L];     
%delay=4e-9*randperm(L);   
%delay=1e-9*[1:L];    
  for i=1:L
      delay=.8e-9; 
      A(i,:)=cp0804_signalshift(mk,Fs,delay);
       mk=A(i,:);
 end
A=A(ml(1:M),(1:L)); 
% %A = A ./ repmat( sqrt(sum(A.^2)), [M 1] );  % to normalize the columns
% %A=A./sqrt(trace(A'*A));
% % for i=1:M
% %     A(i,:)=A(i,:)-mean(A(i,:));
% % end
% % Normalise
% % for i=1:n
% %     P(:,i)=P(:,i)/norm(P(:,i));
% % end
% %% using pulse and channel inforemation
%  ml=randperm(L);
%  %aa=zeros(1,L);
%  %A=zeros(M,L);
%  [hf]=cp0802_channel(Fs,1);
%   aa=conv(w,hf);
%   mk=aa(1:L);
% for i=1:L
%       delay=.4e-9; 
%       A(i,:)=cp0804_signalshift(mk,Fs,delay);
%       mk=A(i,:);
% end
% A=A(ml(1:M),(1:L)); 
% 


