clc;
clear all;
t=linspace(-1e-9,1e-9,51);
dt=t(2)-t(1);
Fs=1/dt; ts=2e-9;
tau=.4e-9; %% pulsse width parameter
w=(1-(4*pi.*(t/tau).^2)).*exp(-2*pi.*(t/tau).^2); % second derivative 
w=w/norm(w);
L=floor(60e-9*Fs);
M=floor(.8*L);
%%%%%%%%%%%%%%%%%%%%%%%%% dictionary generation
%%%%%%%%%%%%%%%% dct matrix
% ml=randperm(L);
% H =dctmtx(L);
% A=H(ml(1:M),(1:L)); 
%  A=A/(norm(A,'fro')); %for 4 and 7
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%A=randn(M,L);
[A]=dictionary_generation(L, M);
Lp=chol((A*A'),'lower'); 
C=inv(Lp); 
A=C*A; 
A=normc(A);
A=normr(A); 

% % %%%%%%%%%%%% Normalise ths row sand column
%  for i=1:M
%   A(i,:)=A(i,:)/norm(A(i,:));
%  end
% % Normalise
% for i=1:L
%     A(:,i)=A(:,i)/norm(A(:,i));
% end





ebno=-10:20;
MMM=2000;
for i=1:MMM
hf(i,:)=cp0802_channel(Fs,1);
w1=conv(w,hf(i,:));
w2=w1(1:L);
sig=w2';
mass=(norm(sig)); %% orginal formula
nt_pow=10.^(-ebno./10);
no=mass./nt_pow;
ber1(i,:)=qfunc(sqrt(no)); % 
% semilogy(ebno(11:24),ber1(i,11:24),'-','LineWidth',1); hold on;
clear  no  w1 w2
end
ber=sum(ber1)/MMM;
hf1=sum(hf)/1000;
clear hf  w ts  sig  dt i L M nt_pow t Fs ber1 tau hf1 C Lp A mass
%  load('ber_dct_4.mat');
%  load('ber_dct_7.mat');
%  load('ber_dct_9.mat');
 %load('ber_hermite_4.mat');
semilogy(ebno(11:25),proposed_theory_3_2,'-bd','LineWidth',.5); hold  on

 
semilogy(ebno(11:25),ber2,'-rx','LineWidth',2); hold on;
% semilogy(x1,y1,'-cd','LineWidth',2); hold  on
% 
% semilogy(x2,y2,'-.','LineWidth',2); hold  on
% semilogy(x3,y3,'-','LineWidth',2); hold  on
semilogy(x4,y4,'-m*','LineWidth',1); hold  on
%semilogy(x5,y5,'-h','LineWidth',2); hold  on
semilogy(x6,y6,'-o','LineWidth',2); hold  on


semilogy(rad_x,random_theory_3,'-.b','LineWidth',2); hold  on






semilogy(ebno,ber,'-rx','LineWidth',2); hold on;
semilogy(ebno,ber_hermite_77,'-bd','LineWidth',2); hold  on



% legend('Theory','Hermite')
semilogy(ebno(11:25),ber_hermite_4(11:25),'-kd','LineWidth',2); hold on;
semilogy(ebno(11:25),1.2*ber_hermite_4_theory(11:25),'-cp','LineWidth',2); hold on;
semilogy(ebno(11:25),ber_hermite_77(11:25),'--r*','LineWidth',1, 'MarkerSize',4); hold on;
semilogy(ebno(11:25),ber_hermite_7_theory(11:25),'--ro','LineWidth',1, 'MarkerSize',4); hold on;


% semilogy(ebno(11:25),ber_Gaussian_44(11:25),'-kd','LineWidth',2); hold on;
% semilogy(ebno(11:25),ber_Gaussian_4_theory(11:25),'-cp','LineWidth',2); hold on;
semilogy(ebno(11:25),ber_Gaussian_7(11:25),'--kx','LineWidth',1, 'MarkerSize',4); hold on;
semilogy(ebno(11:25),ber_Gaussian_7_theory(11:25),'--k>','LineWidth',1, 'MarkerSize',4); hold on;


legend('$\Phi_{Proposed}, \ CR=30$','$\Phi_{Proposed}, \ CR=30, \ (14)$','$\Phi_{Gaussian}, \ CR=30$','$\Phi_{Gaussian}, \ CR=30, \ (14)$')
xlabel('SNR (dB)');
 ylabel('BER')

load('x.mat'); load('y.mat')

x1=x{1};
x2=x{2};
x3=x{3};
x4=x{4};
x5=x{5};
x6=x{6};
y1=y{1};
y2=y{2};
y3=y{3};
y4=y{4};
y5=y{5};
y6=y{6};


