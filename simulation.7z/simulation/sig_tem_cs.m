function [ber]=sig_tem_cs(R,bits,framsample,bitsample,Ns,A,mask1,numbits);
%%% Hard decision detection 
[N,L]=size(R);
rxbits=zeros(N,numbits);
 for n=1:N % for length of snr 
     rx2=R(n,:);
    for nb=1:numbits  %% for bits
        mkk=rx2(1+(nb-1)*bitsample:bitsample+(nb-1)*bitsample);
        mkk1=mask1(1+(nb-1)*bitsample:bitsample+(nb-1)*bitsample);
        N00=0;
        N01=0;
%         mkkp2 =zeros(Ns,framsample);
%          mkkp12 =zeros(Ns,framsample);
        for np=1:Ns  %% for repetation
            mkkp=mkk(1+(np-1)*framsample:framsample+(np-1)*framsample);
            mkkp1=mkk1(1+(np-1)*framsample:framsample+(np-1)*framsample);
        end
%         mkkp=sum(mkkp2)./Ns;
%          mkkp1=sum(mkkp12)./Ns;
            ys=A*mkkp';
            yt=A*mkkp1';
           zp=trapz(ys.*yt);
%            k1l=corrcoef(ys./norm(ys),yt./norm(yt));
%            zp=k1l(1,2);
         if zp>=0;
                N00=N00+1;
         else
                N01=N01+1;
         end
     
              if N00>N01
            rxbits(n,nb)=1;
              else
            rxbits(n,nb)=-1;
              end
     end
 end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
ber=zeros(1,N);
 for  n=1:N
        wb=sum(abs(bits-rxbits(n,:)));
        ber(n)=wb./numbits;
 end
%  plot(mkkp1); hold on; plot(mkkp12(1,:),'r')
%  clear wb si_cs si rxbits bits N tem tem_cs tp 
 
  