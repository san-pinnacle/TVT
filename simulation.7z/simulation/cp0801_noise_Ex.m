function [output,noise]=cp0801_noise_Ex(rx,ebno,numbits)
Eb=(1/numbits)*sum(rx.^2);
%Eb=1;
Ebn0=10.^(ebno./10);
N0=Eb./Ebn0;
nstdv=sqrt(N0/2);
for j=1:length(Ebn0)
    noise(j,:)=nstdv(j).*randn(1,length(rx));
    output(j,:)=noise(j,:)+rx;
end