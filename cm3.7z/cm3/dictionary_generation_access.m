function [A]=dictionary_generation_access(L, M);
t=linspace(-1e-9,1e-9,51);
dt=t(2)-t(1);
Fs=1/dt;
tau=.4e-9; %% pulsse width parameter
w=(1-(4*pi.*(t/tau).^2)).*exp(-2*pi.*(t/tau).^2); % second derivative 
w=w/norm(w);
%%%%%%%%% Hermite function   
ml=randperm(L);
mk=zeros(1,L);
mk(15:38)=((2*(randn>.5))-1)*w(15:38);
mk(39:62)=((2*(randn>.5))-1)*w(15:38);
  for i=1:L
      delay=.7e-9; 
      A(i,:)=cp0804_signalshift(mk,Fs,delay);
       mk=A(i,:);
 end
A=A(ml(1:M),(1:L)); 
