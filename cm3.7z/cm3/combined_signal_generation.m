function [bits, stx,ref,framesample]=combined_signal_generation(numbits,Ns,Np,Nh,Ts,Tc,Fs);
% numbits=10;
% Ns=1;
% Np=100;
% Nh=3;
% Ts=10e-9;
% Tc=1e-9;
t=linspace(-1e-9,1e-9,33);
dt=t(2)-t(1);
Fs=1/dt;
bits=randn(1,numbits)>0.5;
bits=(2*bits)-1;
%% code repetation 
temp=ones(1,Ns);
temp1=zeros(1, numbits*Ns);
temp1(1:Ns:1+Ns*(numbits-1))=bits;
temp2=conv(temp1,temp);
repbits=temp2(1:Ns*numbits); %total bits after repetitation 
numpulse=length(repbits);
%% TH coding
thcode=floor(rand(1,Np).*Nh);
%thcode=0;
%% PPM TH modulation
framesample=floor(Ts./dt);
chipsample=floor(Tc./dt);
Thp=length(thcode);
totallength=framesample*length(repbits);
ppmthseq=zeros(1,totallength);
thseq=zeros(1,totallength);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for k=1:length(repbits)
index=1+(k-1)*framesample; % for pulse position
kth=thcode(1+mod(k-1,Thp));
index1=index+kth*chipsample;
thseq(index1)=1;
ppmthseq(index1)=repbits(k);
end
%% pulse generation
tau=0.35e-9;
si2=(1-4*pi.*(t/tau).^2).*exp(-2*pi.*(t/tau).^2); % second derivative Gaussian pulse
wtx=si2./norm(si2);
sa=conv(ppmthseq,wtx);
sb=conv(thseq,wtx);
L1=(floor(Ts*1./dt))*Ns*numbits;%size of transmitted pulse
stx=sa(1:L1); % modulated signal
ref=sb(1:L1);%reference siagnal

