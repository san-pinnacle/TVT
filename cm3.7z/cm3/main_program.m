clc
clear all;
close all;
%%%%%%%%%%%%%%%%%
 % this progarm generate the BPSk signal and its perfroamnce in compressed
 % doamin using the Hermite  matrix. various compression ratio tests are
 % perfromed  and  compared 
numbits=100;
Ns=1;
Np=100; %Chip period
Nh=7; % cardinality
Ts=100e-9; % frame duration
Tc=1e-9; % chip duration
Fs=16e9;
dt=1./Fs;
[bits, stx,ref,framesample]=combined_signal_generation(numbits,Ns,Np,Nh,Ts,Tc,Fs); %% generted tranmitted signal
bitsample=framesample*Ns;
%ebno=inf;
ebno=0:2:30;
%%% Hermite matrix generation
 NN=framesample;
 MM=floor(.3*NN);
% A=randn(MM,NN);
[A]=dictionary_generation(NN, MM);
% [A]=dictionary_generation_access(NN, MM);
L=chol((A*A'),'lower'); 
C=inv(L); 
A=C*A; 
A=normc(A);
A=normr(A);
Len=floor(Ts*Fs)-1;
nn=5000;
for j=1:nn 
 %A=randn(MM,NN);
% [A]=dictionary_generation(NN, MM);
%[A]=dictionary_generation_access(NN, MM);
% L=chol((A*A'),'lower'); 
% C=inv(L); 
% A=C*A; 
% A=normc(A);
% A=normr(A);  
%     
    
[hf]=cp0802_channel(Fs,1, Len);
%% channel estimation
% L=5; S=5;
% [arake, srake,prake]=channel_estimation(hf,Fs,2e-9,L,S);
% clear hf prake arake
% hf=srake;
%% received signal
srx=conv(stx,hf);
srx=srx(1:length(stx));
%% nois egeneration
[~,noise]=cp0801_noise_Ex(1.2*stx,ebno,(numbits*Ns));
[ref1]=cp0801_mask(ref,hf); %% reference signal estimation
%%%%%% noise addtiton
R=zeros(length(ebno),length(srx));
 for l=1:length(ebno)
  R(l,:)=noise(l,:)+srx;
 end
 [ber1(j,:)]=sig_tem_cs(R,bits,framesample,bitsample,Ns,ref1,numbits,A);
clear srx hf R noise  ref1
 end 
ber=sum(ber1)/nn;

clear hf ber1  Tf Ns Np L bits R w t framesample framesample1 Fs ho j k  ns stx tau ts
clear MM NN Ts  prake ml I H dt bitsample arake output ref1 ref S L l Nh numbits Tc nn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
semilogy(ebno,ber,'-rd','LineWidth',2); hold on;

semilogy(ebno,ber_circulant_3_cm3,'-*','LineWidth',2); hold on

semilogy(ebno,ber_proposed_3_cm3,'--ro','LineWidth',1); hold on;

semilogy(ebno,ber_random_3_cm3,'--','LineWidth',1); hold on;


ber_proposed_3_cm3_2
%%%%% plot multipath
width=4; height=3.5;
figure('Units','inches',...
'Position',[0 0 width height],...
'PaperPositionMode','auto');

% % line_fewer_markers(x1,f1,12,  '-ko','spacing','curve','MarkerSize',6); hold on; 
%  line_fewer_markers(ebno,ber_random_3,32,'-ko','spacing','logx','linewidth',1,'markersize',5); hold on
%   line_fewer_markers(ebno,ber_circulant_3,30,'--b>','spacing','logx','linewidth',1,'markersize',5); hold on
%  line_fewer_markers(ebno,ber_proposed_3_2,24,'-.rd','spacing','logx','linewidth',1,'markersize',5); hold on
% set(gca,'YScale','log')
 semilogy(ebno,ber_random_3_cm3,'-o','color','b','LineWidth',1, 'MarkerSize',5); hold on
semilogy(ebno,ber_circulant_3_cm3_2,'-d','color','r','LineWidth',1, 'MarkerSize',5); hold on
semilogy(ebno,ber_proposed_3_cm3_2,'->','color','k','LineWidth',1, 'MarkerSize',3); hold on
legend('Random','Circulant','Proposed')
xlabel('SNR (dB)');
ylabel('BER')



print -depsc2 ber_cm3.eps


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[x] = OMP( A, A*stx(1:2499)', {1e-2}, [], [] )
[x] = spg_bp(A,A*R(20,1:2499)',[] )
 xomp = omp(A,A*R(20,1:2499)',100);