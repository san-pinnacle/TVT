function [mui]=interference_mui(numbits,Ns,Np,Nh,Ts,Tc,Fs);
Np=1000; Nh=10;
for i=1:10
[bits, stx,ref,framesample]=combined_signal_generation(numbits,Ns,Np,Nh,Ts,Tc,Fs); %% generted tranmitted signal
[hf]=cp0802_channel(Fs,1);
srx1=conv(stx,hf);
srx(i,:)=srx1(1:length(stx));
end
mui=sum(srx);

