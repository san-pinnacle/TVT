function [x] = mp(A,b)
% compute k-sparse approximation to b with matrix A using Matching pursuit
[m,N] = size(A); 
x = zeros(N,1); 
res = b; 
while  norm(res)>=1e-2;
% compute correlation between residual and columns of A
corr = A'*res; 
% find position n (and value c) of the maximally correlated column 
[c n] = max(abs(corr)); % NB: modern Matlab notation allows [~ n] = max(abs(corr)) 
% update the representation 
x(n) = x(n) + corr(n);     
% update the residual
res = res - corr(n)*A(:,n) ; 
end


% xx=stx(1:2499);
% b=A*xx';
