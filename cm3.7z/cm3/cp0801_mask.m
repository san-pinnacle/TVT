function [mask1]=cp0801_mask(ref1,rake);
ref11=conv(ref1,rake);
mask1=ref11(1:length(ref1));
